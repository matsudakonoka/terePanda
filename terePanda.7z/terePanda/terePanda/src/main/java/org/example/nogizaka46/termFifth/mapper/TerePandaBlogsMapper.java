package org.example.nogizaka46.termFifth.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.example.nogizaka46.termFifth.entity.TerePandaBlogs;
@Mapper
public interface TerePandaBlogsMapper extends BaseMapper<TerePandaBlogs> {

}
