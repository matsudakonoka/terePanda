package org.example.nogizaka46.termFifth.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.example.nogizaka46.termFifth.entity.TerePandaVideos;

@Mapper
public interface TerePandaVideosMapper extends BaseMapper<TerePandaVideos> {

}